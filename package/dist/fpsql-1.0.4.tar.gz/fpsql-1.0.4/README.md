# FPSQL
An easy to use SQLite package
#### Change log:
###### v.1.0.4:
Fix all mypy stub issues
###### v.1.0.3:
Provide a mypy stub file
###### v.1.0.2:
Fix internal vars
###### v.1.0.1:
Actual release
###### v.1.0.0:
Initial Release!
###### v.1.0.26:
Mistake release :facepalm: