# fkeycapture
This is a simple and easy to use package that allows you to capture individual keystrokes from the user.
#### Forms:
1. (Default) Recive key as a string
2. Recive key as bytes