# Firepup650
Package containing various shorthand things I use, and a few imports I almost always use
#### Change log:
###### v.1.0.1:
Added animated typing function, sleep shorthand
###### v.1.0.0:
Initial Release!